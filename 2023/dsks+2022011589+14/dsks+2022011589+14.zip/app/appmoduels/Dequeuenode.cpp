#include "Dequeuenode.h"
Dequeuenode::Dequeuenode()
{
}
Dequeuenode::~Dequeuenode()
{
}