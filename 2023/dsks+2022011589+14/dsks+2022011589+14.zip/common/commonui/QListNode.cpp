#include "QListNode.h"

QListNode::QListNode()
{

}
QListNode::~QListNode()
{

}