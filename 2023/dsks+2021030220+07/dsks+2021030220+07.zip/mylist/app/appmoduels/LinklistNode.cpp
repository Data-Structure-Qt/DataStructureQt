#include "LinklistNode.h"
LinklistNode::LinklistNode()
{
}
LinklistNode::~LinklistNode()
{
}