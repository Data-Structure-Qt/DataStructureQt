﻿#pragma once
#include <iostream>
#include <vector>
#include <algorithm>
#include <QCoreApplication>
#include <QDebug>

class MyNode {
public:
	int data;
	MyNode* next;
	// 创建单链表
	static MyNode* createList(std::vector<int> elements);

	// 获取两个有序单链表的交集
	static MyNode* getIntersection(MyNode* list1, MyNode* list2);

	// 获取两个有序单链表的并集
	static MyNode* getUnion(MyNode* list1, MyNode* list2);

	// 获取两个有序单链表的差集
	static MyNode* getDifference(MyNode* list1, MyNode* list2);


};

