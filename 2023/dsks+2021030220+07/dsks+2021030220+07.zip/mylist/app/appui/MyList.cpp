﻿#include "MyList.h"

// 创建单链表

MyNode* MyNode::createList(std::vector<int> elements) {
	MyNode* head = nullptr;
	MyNode* current = nullptr;

	for (int element : elements) {
		MyNode* newNode = new MyNode();
		newNode->data = element;
		newNode->next = nullptr;

		if (head == nullptr) {
			head = newNode;
			current = newNode;
		}
		else {
			current->next = newNode;
			current = newNode;
		}
	}

	return head;
}

// 获取两个有序单链表的交集

MyNode* MyNode::getIntersection(MyNode* list1, MyNode* list2) {
	MyNode* intersection = nullptr;
	MyNode* current = nullptr;

	while (list1 != nullptr && list2 != nullptr) {
		if (list1->data < list2->data) {
			list1 = list1->next;
		}
		else if (list1->data > list2->data) {
			list2 = list2->next;
		}
		else {
			MyNode* newNode = new MyNode();
			newNode->data = list1->data;
			newNode->next = nullptr;

			if (intersection == nullptr) {
				intersection = newNode;
				current = newNode;
			}
			else {
				current->next = newNode;
				current = newNode;
			}

			list1 = list1->next;
			list2 = list2->next;
		}
	}

	return intersection;
}

// 获取两个有序单链表的并集

MyNode* MyNode::getUnion(MyNode* list1, MyNode* list2) {
	MyNode* unionSet = nullptr;
	MyNode* current = nullptr;

	while (list1 != nullptr && list2 != nullptr) {
		if (list1->data < list2->data) {
			MyNode* newNode = new MyNode();
			newNode->data = list1->data;
			newNode->next = nullptr;

			if (unionSet == nullptr) {
				unionSet = newNode;
				current = newNode;
			}
			else {
				current->next = newNode;
				current = newNode;
			}

			list1 = list1->next;
		}
		else if (list1->data > list2->data) {
			MyNode* newNode = new MyNode();
			newNode->data = list2->data;
			newNode->next = nullptr;

			if (unionSet == nullptr) {
				unionSet = newNode;
				current = newNode;
			}
			else {
				current->next = newNode;
				current = newNode;
			}

			list2 = list2->next;
		}
		else {
			MyNode* newNode = new MyNode();
			newNode->data = list1->data;
			newNode->next = nullptr;

			if (unionSet == nullptr) {
				unionSet = newNode;
				current = newNode;
			}
			else {
				current->next = newNode;
				current = newNode;
			}

			list1 = list1->next;
			list2 = list2->next;
		}
	}

	// 将剩余元素添加到并集中
	while (list1 != nullptr) {
		MyNode* newNode = new MyNode();
		newNode->data = list1->data;
		newNode->next = nullptr;

		current->next = newNode;
		current = newNode;

		list1 = list1->next;
	}

	while (list2 != nullptr) {
		MyNode* newNode = new MyNode();
		newNode->data = list2->data;
		newNode->next = nullptr;

		current->next = newNode;
		current = newNode;

		list2 = list2->next;
	}

	return unionSet;
}

// 获取两个有序单链表的差集

MyNode* MyNode::getDifference(MyNode* list1, MyNode* list2) {
	MyNode* difference = nullptr;
	MyNode* current = nullptr;

	while (list1 != nullptr && list2 != nullptr) {
		if (list1->data < list2->data) {
			MyNode* newNode = new MyNode();
			newNode->data = list1->data;
			newNode->next = nullptr;

			if (difference == nullptr) {
				difference = newNode;
				current = newNode;
			}
			else {
				current->next = newNode;
				current = newNode;
			}

			list1 = list1->next;
		}
		else if (list1->data > list2->data) {
			list2 = list2->next;
		}
		else {
			list1 = list1->next;
			list2 = list2->next;
		}
	}

	while (list1 != nullptr) {
		MyNode* newNode = new MyNode();
		newNode->data = list1->data;
		newNode->next = nullptr;

		current->next = newNode;
		current = newNode;

		list1 = list1->next;
	}

	return difference;
}
