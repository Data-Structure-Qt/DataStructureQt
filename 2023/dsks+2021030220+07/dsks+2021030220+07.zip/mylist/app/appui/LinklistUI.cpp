﻿#include "LinklistUI.h" 
#include "ui_LinklistUI.h" 
#include "CNodeEditorScene.h" 
#include <QFile> 
#include <QTextStream> 
#include <QTime> 
#include <qDebug>
LinklistUI::LinklistUI(QWidget* parent) :
	QWidget(parent),
	ui(new Ui::LinklistUI),
	m_scene(NULL)
{
	ui->setupUi(this);
	ui->groupBox_2->hide();
	ui->groupBox_3->hide();
	ui->groupBox_4->hide();
	connect(ui->pushButton_2, &QPushButton::clicked, this, [=]() {
		auto node = MyNode::getIntersection(node1, node2);
		showNodeList(node, 2);
		});
	connect(ui->pushButton_3, &QPushButton::clicked, this, [=]() {
		auto node = MyNode::getUnion(node1, node2);
		showNodeList(node, 3);
		});
	connect(ui->pushButton, &QPushButton::clicked, this, [=]() {
		auto node = MyNode::getDifference(node1, node2);
		showNodeList(node, 4);
		});

}
void LinklistUI::goToBeginButton()
{
	endplaybuttonflag = 1;
	timestamp = 0;
	m_scene->clearScreen();//清屏
	for (int j = 0; j <= frametime[0]; j++)
	{
		animationDraw(0, j);
	}
}
void LinklistUI::stepBackButton()
{
	endplaybuttonflag = 1;
	if (timestamp > 0)
	{
		timestamp--;
		m_scene->clearScreen();//清屏
		for (int j = 0; j <= frametime[timestamp]; j++)
		{
			animationDraw(timestamp, j);
		}
	}
}
void LinklistUI::playButton()
{
	endplaybuttonflag = 0;
	m_scene->clearScreen();//清屏
	for (int j = 0; j <= frametime[onlytotaltime]; j++)
	{
		animationDraw(onlytotaltime, j);
		m_quickHelp->head_insert_code(1);
	}
	timestamp = onlytotaltime;
	sleepTime(500);
}
void LinklistUI::suspendButton() {
	endplaybuttonflag = 1;
}
void LinklistUI::stepForwardButton() {
	endplaybuttonflag = 1;
	if (timestamp < onlytotaltime)
	{
		timestamp++;
		m_scene->clearScreen();//清屏
		for (int j = 0; j <= frametime[timestamp]; j++)
		{
			animationDraw(timestamp, j);
		}
	}
}
void LinklistUI::goToEndButton() {
	endplaybuttonflag = 1;
	m_scene->clearScreen();//清屏
	timestamp = onlytotaltime;
	for (int j = 0; j <= frametime[onlytotaltime]; j++)
	{
		animationDraw(onlytotaltime, j);
	}
	//m_quickHelp->btree_insert_code(insertIdCode[timestamp]);
}
void LinklistUI::sleepTime(int time)
{
	QTime dieTime = QTime::currentTime().addMSecs(time);//获取自定义休眠时间
	while (QTime::currentTime() < dieTime)
	{
		QCoreApplication::processEvents(QEventLoop::AllEvents, 100);//开启新线程，	处理 qt 界面事件
	}
}
void LinklistUI::animationRecord(int totaltime, int frame, int x, int data)
{
	animation[totaltime][frame].x = x;
	animation[totaltime][frame].data = data;
}
void LinklistUI::animationSearchRecord(int totaltime, int frame, int x, int data, int flag, int
	codeid)
{
	animationSearch[totaltime][frame].x = x;
	animationSearch[totaltime][frame].data = data;
	animationSearch[totaltime][frame].flag = flag;
	animationSearch[totaltime][frame].codeid = codeid;
}
void LinklistUI::animationClean()
{
	for (int i = 0; i < 200; i++)
	{
		for (int j = 0; j < 200; j++)
		{
			animation[i][j].x = 0;
			animation[i][j].data = 0;
		}
	}
}
void LinklistUI::animationPrint(int totaltime, int frametime)
{
	qDebug() << "totaltime" << totaltime;
	qDebug() << "frametime" << frametime;
	int i = totaltime;
	int j = frametime;
	qDebug() << "animation[i].x " << animation[i][j].x;
	qDebug() << " animation[i].data " << animation[i][j].data;
}
void LinklistUI::animationDraw(int totaltime, int frametime)
{
	m_scene->insertnode(animation[totaltime][frametime].x,
		animation[totaltime][frametime].data); //链表只需要便利每个结点一次即可
}
void LinklistUI::animationDrawSearch(int totaltime, int frametime, int x)
{
	m_scene->insertfindnode(animation[totaltime][frametime].x,
		animation[totaltime][frametime].data);
}
/// <summary>
/// 进行list的显示
/// </summary>
/// <param name="node">头节点</param>
/// <param name="jindex">显示在第几行</param>
void LinklistUI::showNodeList(MyNode* node, int jindex)
{
	int index = 0;
	while (node != nullptr)
	{
		int data = node->data;
		QString tmp = QString::number(data);
		m_scene->insertnode({ index++,jindex }, data);//向屏幕绘制
		node = node->next;
	}
}
//......
void LinklistUI::onSceneDetached(CEditorScene* scene)
{
	scene->disconnect(this);
}
void LinklistUI::setScene(CNodeEditorScene* scene)
{
	if (m_scene)
		onSceneDetached(m_scene);
	m_scene = scene;
	setEnabled(m_scene);
	if (m_scene)
		onSceneAttached(m_scene);
}
void LinklistUI::onSceneAttached(CEditorScene* scene)
{
}
void LinklistUI::setCQuickHelpUI(CQuickHelpUI* quickHelp)
{
	m_quickHelp = quickHelp;
	setEnabled(m_quickHelp);
}
LinklistUI::~LinklistUI()
{
}

void LinklistUI::on_create_btn_clicked()
{
	m_scene->clearScreen();
	std::vector<int> list1, list2;
	QString data1 = ui->dataEdit->text();
	QStringList temp1 = data1.split(",");

	QString data2 = ui->dataEdit_3->text();
	QStringList temp2 = data2.split(",");

	for (int i = 0; i < temp1.size(); ++i)
	{
		list1.push_back(temp1[i].toInt());
	}

	for (int i = 0; i < temp2.size(); ++i)
	{
		LinklistNode* node = new LinklistNode();
		node->m_StrName = temp2.at(i);
		//添加进链表
		list2.push_back(temp2[i].toInt());

	}

	node1 = MyNode::createList(list1);
	node2 = MyNode::createList(list2);

	showNodeList(node1, 0);
	showNodeList(node2, 1);

}


void LinklistUI::on_clean_btn_clicked() //清除按钮槽函数
{
	m_scene->clearScreen();
	ui->dataEdit->clear();
	ui->dataEdit_3->clear();

	for (int i = 1; i <= QLinkList1.size(); ++i)
	{
		m_scene->deletenode(i);
	}
	QLinkList1.clear();
}
void LinklistUI::on_headinsert_btn_clicked()
{
	int temp = 0;
	for (int j = 0; j <= frametime[onlytotaltime]; j++)
	{
		animationRecord(0, j, animation[onlytotaltime][j].x,
			animation[onlytotaltime][j].data);
		temp = j;
	}
	onlytotaltime = 0;
	frametime[onlytotaltime] = temp;
	for (int i = 1; i <= QLinkList1.size(); ++i)
	{
		m_scene->deletenode(i);
	}
	QString data = ui->insert_Edit1->text();
	LinklistNode* node = new LinklistNode();
	node->m_StrName = data;
	QLinkList1.insert(0, *node);
	onlytotaltime++;
	for (int i = 0; i < QLinkList1.size(); ++i)
	{
		QString tmp = QLinkList1.at(i).m_StrName;
		bool ok2;
		int x = tmp.toUInt(&ok2);
		if (!ok2)
			return;
		m_scene->insertnode(i, x);
		animationRecord(1, i, i, x);
		frametime[onlytotaltime] = i;
	}
	ui->spinBox->setRange(0, frametime[onlytotaltime]);
	ui->insert_spinBox->setRange(0, frametime[onlytotaltime]);
	ui->delete_spinBox->setRange(0, frametime[onlytotaltime]);
	timestamp = 1;
	m_quickHelp->head_insert_code(1);
}
void LinklistUI::on_tailinsert_btn_clicked() //尾部插入按钮槽函数
{
	// 记录初始状态，并将时间轴置为 0
// 此处编写代码
	int temp = 0;
	for (int j = 0; j <= frametime[onlytotaltime]; j++)
	{
		animationRecord(0, j, animation[onlytotaltime][j].x, animation[onlytotaltime][j].data);
		temp = j;
	}
	onlytotaltime = 0;
	frametime[onlytotaltime] = temp;
	for (int i = 1; i <= QLinkList1.size(); ++i) //清屏后创建
	{
		m_scene->deletenode(i);
	}
	QString data = ui->insert_Edit1->text();
	int list_size = QLinkList1.size();
	LinklistNode* node = new LinklistNode();
	node->m_StrName = data;
	QLinkList1.insert(list_size, *node); //尾部插入
	onlytotaltime++;
	for (int i = 0; i < QLinkList1.size(); ++i)
	{
		QString tmp = QLinkList1.at(i).m_StrName;
		bool ok2;
		int x = tmp.toUInt(&ok2);
		if (!ok2)
			return;
		m_scene->insertnode(i, x);
		animationRecord(1, i, i, x);
		frametime[onlytotaltime] = i;
	}
	ui->spinBox->setRange(0, frametime[onlytotaltime]);
	ui->insert_spinBox->setRange(0, frametime[onlytotaltime]);
	ui->delete_spinBox->setRange(0, frametime[onlytotaltime]);
	timestamp = 1;
}
void LinklistUI::on_locationinsert_btn_clicked() //任意位置插入按钮槽函数
{
	// 记录初始状态，并将时间轴置为 0
// 此处编写代码
	int temp = 0;
	for (int j = 0; j <= frametime[onlytotaltime]; j++)
	{
		animationRecord(0, j, animation[onlytotaltime][j].x,
			animation[onlytotaltime][j].data);
		temp = j;
	}
	onlytotaltime = 0;
	frametime[onlytotaltime] = temp;
	for (int i = 1; i <= QLinkList1.size(); ++i) //清屏后创建
	{
		m_scene->deletenode(i);
	}
	QString data = ui->insert_Edit2->text();
	int num = ui->insert_spinBox->value();
	int list_size = QLinkList1.size();
	if (num<0 || num > list_size + 1)//超过插入范围返回
	{
		return;
	}
	LinklistNode* node = new LinklistNode();
	node->m_StrName = data;
	QLinkList1.insert(num, *node); //某个位置插入
	onlytotaltime++;
	for (int i = 0; i < QLinkList1.size(); ++i)
	{
		QString tmp = QLinkList1.at(i).m_StrName;
		bool ok2;
		int x = tmp.toUInt(&ok2);
		if (!ok2)
			return;
		m_scene->insertnode(i, x);
		animationRecord(1, i, i, x);
		frametime[onlytotaltime] = i;
	}
	ui->spinBox->setRange(0, frametime[onlytotaltime]);
	ui->insert_spinBox->setRange(0, frametime[onlytotaltime]);
	ui->delete_spinBox->setRange(0, frametime[onlytotaltime]);
	timestamp = 1;
	m_quickHelp->head_insert_code(1);
}
void LinklistUI::on_headdelete_btn_clicked() //头部移除按钮槽函数
{
	// 记录初始状态，并将时间轴置为 0
// 此处编写代码
	int temp = 0;
	for (int j = 0; j <= frametime[onlytotaltime]; j++)
	{
		animationRecord(0, j, animation[onlytotaltime][j].x,
			animation[onlytotaltime][j].data);
		temp = j;
	}
	onlytotaltime = 0;
	frametime[onlytotaltime] = temp;
	for (int i = 1; i <= QLinkList1.size(); ++i) //清屏后创建
	{
		m_scene->deletenode(i);
	} if (!QLinkList1.isEmpty())
	{
		QLinkList1.removeFirst();//删除第一个元素
	}
	onlytotaltime++;
	for (int i = 0; i < QLinkList1.size(); ++i)
	{
		QString tmp = QLinkList1.at(i).m_StrName;
		bool ok2;
		int x = tmp.toUInt(&ok2);
		if (!ok2)
			return;
		m_scene->insertnode(i, x);
		animationRecord(1, i, i, x);
		frametime[onlytotaltime] = i;
	}
	ui->spinBox->setRange(0, frametime[onlytotaltime]);
	ui->insert_spinBox->setRange(0, frametime[onlytotaltime]);
	ui->delete_spinBox->setRange(0, frametime[onlytotaltime]);
	timestamp = 1;
	m_quickHelp->location_delete_code(1);
}
void LinklistUI::on_taildelete_btn_clicked() //尾部移除按钮槽函数
{
	// 记录初始状态，并将时间轴置为 0
// 此处编写代码
	int temp = 0;
	for (int j = 0; j <= frametime[onlytotaltime]; j++)
	{
		animationRecord(0, j, animation[onlytotaltime][j].x, animation[onlytotaltime][j].data);
		temp = j;
	}
	onlytotaltime = 0;
	frametime[onlytotaltime] = temp;
	for (int i = 1; i <= QLinkList1.size(); ++i) //清屏后创建
	{
		m_scene->deletenode(i);
	}
	if (!QLinkList1.isEmpty())
	{
		QLinkList1.removeLast();//删除最后一个元素
	}
	onlytotaltime++;
	for (int i = 0; i < QLinkList1.size(); ++i)
	{
		QString tmp = QLinkList1.at(i).m_StrName;
		bool ok2;
		int x = tmp.toUInt(&ok2);
		if (!ok2)
			return;
		m_scene->insertnode(i, x);
		animationRecord(1, i, i, x);
		frametime[onlytotaltime] = i;
	}
	ui->spinBox->setRange(0, frametime[onlytotaltime]);
	ui->insert_spinBox->setRange(0, frametime[onlytotaltime]);
	ui->delete_spinBox->setRange(0, frametime[onlytotaltime]);
	timestamp = 1;
	m_quickHelp->location_delete_code(1);
}
void LinklistUI::on_locationdelete_btn_clicked() //任意位置移除按钮槽函数
{
	// 记录初始状态，并将时间轴置为 0
// 此处编写代码
	int temp = 0;
	for (int j = 0; j <= frametime[onlytotaltime]; j++)
	{
		animationRecord(0, j, animation[onlytotaltime][j].x, animation[onlytotaltime][j].data);
		temp = j;
	}
	onlytotaltime = 0;
	frametime[onlytotaltime] = temp;
	for (int i = 1; i <= QLinkList1.size(); ++i) //清屏后创建
	{
		m_scene->deletenode(i);
	} int num = ui->delete_spinBox->value();
	int list_size = QLinkList1.size();
	if (num<0 || num > list_size + 1)//超过删除范围返回
	{
		return;
	}
	if (!QLinkList1.isEmpty())
	{
		QLinkList1.removeAt(num);//删除指定元素
	}
	onlytotaltime++;
	for (int i = 0; i < QLinkList1.size(); ++i)
	{
		QString tmp = QLinkList1.at(i).m_StrName;
		bool ok2;
		int x = tmp.toUInt(&ok2);
		if (!ok2)
			return;
		m_scene->insertnode(i, x);
		animationRecord(1, i, i, x);
		frametime[onlytotaltime] = i;
	}
	ui->spinBox->setRange(0, frametime[onlytotaltime]);
	ui->insert_spinBox->setRange(0, frametime[onlytotaltime]);
	ui->delete_spinBox->setRange(0, frametime[onlytotaltime]);
	timestamp = 1;
	m_quickHelp->location_delete_code(1);
}
void LinklistUI::on_search_btn_clicked() //槽函数
{
	QString findata = ui->search_Edit->text();
	m_scene->clearScreen();//清屏
	int lsize = QLinkList1.size();
	for (int i = 1; i <= lsize; ++i) {
		if (!QLinkList1.isEmpty()) {
			QLinkList1.removeLast(); //删除最后一个元素
		}
	}
	QList<CNode*> nodes = m_scene->getSelectedNodes();
	QString data = ui->dataEdit->text();
	QStringList temp = data.split(",");
	for (int i = 0; i < temp.size(); ++i) {
		LinklistNode* node = new LinklistNode();
		node->m_StrName = temp.at(i);
		//添加进链表
		QLinkList1.append(*node);
	}
	for (int j = 0; j < QLinkList1.size(); ++j) {
		QTime dieTime2 = QTime::currentTime().addMSecs(400);//休眠时间
		while (QTime::currentTime() < dieTime2)
			QCoreApplication::processEvents(QEventLoop::AllEvents, 400);
		QTime dieTime3 = QTime::currentTime().addMSecs(400);//休眠时间
		while (QTime::currentTime() < dieTime3)
			QCoreApplication::processEvents(QEventLoop::AllEvents, 400);
		QString tmpj = QLinkList1.at(j).m_StrName;
		for (int k = 1; k <= 3; k++)//闪烁三次
		{
			m_scene->clearScreen();//清屏
			for (int i = 0; i < QLinkList1.size(); ++i) {
				QString tmp = QLinkList1.at(i).m_StrName;
				bool flag;
				int x = tmp.toUInt(&flag);
				if (!flag)
					return;
				if (k % 2 == 1) {
					if (tmp != tmpj) {
						m_scene->insertnode(i, x);//向屏幕绘制
					}
					else {
						m_scene->insertfindnode(i, x);//向屏幕绘制 红标
					}
				}
				else {
					m_scene->insertnode(i, x);//向屏幕绘制
				}
			}
			QTime dieTime = QTime::currentTime().addMSecs(200);//获取自定义休眠时间
			while (QTime::currentTime() < dieTime)
				QCoreApplication::processEvents(QEventLoop::AllEvents, 200);
		}
		if (tmpj == findata)//若相等，则不再绘制
		{
			QTime dieTime6 = QTime::currentTime().addMSecs(400);//休眠时间
			while (QTime::currentTime() < dieTime6)
				QCoreApplication::processEvents(QEventLoop::AllEvents, 400);
			m_quickHelp->search_code(1); //代码区域
			return;
		}
		QTime dieTime = QTime::currentTime().addMSecs(200);//获取自定义休眠时间
		while (QTime::currentTime() < dieTime)
			QCoreApplication::processEvents(QEventLoop::AllEvents, 200);
	}
	m_quickHelp->search_code(1); //代码区域
}